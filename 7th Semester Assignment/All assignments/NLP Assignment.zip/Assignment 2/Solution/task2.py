import gensim
import numpy as np

sentences = gensim.models.word2vec.LineSentence('text.txt')

skip_gram_model = gensim.models.Word2Vec(sentences, vector_size=100, window=5, min_count=1, workers=4, sg=1)
cbow_model = gensim.models.Word2Vec(sentences, vector_size=100, window=5, min_count=1, workers=4, sg=0)

word_pairs = [('cat', 'dog'), ('apple', 'orange'), ('king', 'queen')]

def cosine_similarity(v1, v2):
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))

for w1, w2 in word_pairs:
    if w1 in skip_gram_model.wv and w2 in skip_gram_model.wv and w1 in cbow_model.wv and w2 in cbow_model.wv:
        v1_sg = skip_gram_model.wv[w1]
        v2_sg = skip_gram_model.wv[w2]
        v1_cbow = cbow_model.wv[w1]
        v2_cbow = cbow_model.wv[w2]

        sim_sg = cosine_similarity(v1_sg, v2_sg)
        sim_cbow = cosine_similarity(v1_cbow, v2_cbow)

        print(f"Cosine similarity between {w1} and {w2} using skip-gram: {sim_sg:.3f}")
        print(f"Cosine similarity between {w1} and {w2} using CBOW: {sim_cbow:.3f}")
    else:
        print(f"One or both of the words '{w1}' and '{w2}' not present in the vocabulary.")
