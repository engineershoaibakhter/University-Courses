import re

email_regex = r"\w+@\w+\.(com|edu)"
phone_regex = r"(021|042)-\d{7}"

email_examples = ["amjad5azx@gmail.com", "zaid@bing.edu", "saad@yahoo.net"]
phone_examples = ["021-1234567", "042-7654321", "051-9876543"]

for email in email_examples:
    if re.match(email_regex, email):
        print(email, "is a valid email address with .com or .edu domain")
    else:
        print(email, "is not a valid email address with .com or .edu domain")

print('\n')
for phone in phone_examples:
    if re.match(phone_regex, phone):
        print(phone, "is a valid Karachi or Lahore phone number")
    else:
        print(phone, "is not a valid Karachi or Lahore phone number")