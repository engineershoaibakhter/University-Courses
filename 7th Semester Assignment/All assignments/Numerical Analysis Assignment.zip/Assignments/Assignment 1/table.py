from docx import Document

# Create a new Word document
doc = Document()

# Add a title
doc.add_heading("Comparison of Linear and Quadratic Convergence", level=1)

# Create the table
table = doc.add_table(rows=1, cols=8)

# Define table headings
table.style = 'Table Grid'
headings = table.rows[0].cells
headings[0].text = "Characteristic"
headings[1].text = "Linear Convergence"
headings[2].text = ""
headings[3].text = "Quadratic Convergence"
headings[4].text = ""
headings[5].text = ""
headings[6].text = ""
headings[7].text = ""

# Add data to the table
data = [
    ["Rate of Convergence", "The error decreases at a constant rate with each iteration. Mathematically: e_n ~ C * e_(n-1), where 'C' is a constant less than 1.",
     "The error decreases at a rate that is the square of the previous error. Mathematically: e_n ~ C * (e_(n-1))^2, where 'C' is a constant greater than 0."],
    ["Characteristics", "Progress is consistent but relatively slow, resulting in gradual convergence.",
     "Progress is significantly faster, leading to rapid convergence to the solution."],
    ["Speed of Convergence", "Slower convergence compared to quadratic.", "Much faster convergence compared to linear."],
    ["Examples", "Jacobi and Gauss-Seidel methods for solving linear systems, bisection method for root-finding.",
     "Newton-Raphson method for root-finding, advanced optimization algorithms."],
    ["Convergence Rate", "The number of iterations required for the error to reduce by a fixed factor (e.g., half) is approximately constant.",
     "The number of iterations required for the error to reduce by a fixed factor decreases significantly with each iteration."],
    ["Convergence Factors", "Convergence is influenced by the magnitude of 'C' in the linear equation. Smaller 'C' values result in slower convergence.",
     "Convergence is highly influenced by the magnitude of 'C' in the quadratic equation. Larger 'C' values result in faster convergence."],
    ["Local Convergence Behavior", "Linear convergence is often seen when an iterative method approaches a root or solution but hasn't reached it yet.",
     "Quadratic convergence typically occurs when an iterative method is close to the desired root or solution and exhibits rapid refinement."],
    ["Sensitivity to Initial Guess", "Linear convergence may require more iterations and be sensitive to initial guesses, especially when dealing with ill-conditioned problems.",
     "Quadratic convergence is often less sensitive to initial guesses and can quickly refine the solution."]
]

for row in data:
    row_cells = table.add_row().cells
    for i, cell_text in enumerate(row):
        row_cells[i].text = cell_text

# Save the document
doc.save("ConvergenceComparison.docx")
